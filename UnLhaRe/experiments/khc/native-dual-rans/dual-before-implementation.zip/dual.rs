//! 二つの独立stateと共有byte列を使う研究用rANS。Cコードの移植ではない。
//! 方式の一次資料: Fabian Giesen, rans_byte.h (2014, public domain)。
//! https://github.com/rygorous/ryg_rans/blob/master/rans_byte.h
//! 実装前の有限失敗条件: lane/total/c/f/tag/state境界、空・片lane・同lane連続、
//! Q8/Q15混在と逆emit/init順序、全prefix切断・末尾追加・非正規終端、consume失敗時の
//! 両state/cursor不変、event cap直外を一度、旧cap+次capの事前支払と実cap確認。
//! 正常列は別のu64式oracleと全byteを比較して両decoderで往復する。文法のimplicit
//! step順序は呼出し側の検査責任。本fileのfinite()は(runs, rejected, rollback)を返す。
//! allocator内部の一時領域やRSSをこの論理capacity境界で保証したとは扱わない。
